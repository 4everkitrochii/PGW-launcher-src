using engine.data;

public class Settings : BaseSharedSettings
{
}

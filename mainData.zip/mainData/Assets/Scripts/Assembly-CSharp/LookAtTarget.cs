using UnityEngine;

public class LookAtTarget : MonoBehaviour
{
	public int level;
	public Transform target;
	public float speed;
}

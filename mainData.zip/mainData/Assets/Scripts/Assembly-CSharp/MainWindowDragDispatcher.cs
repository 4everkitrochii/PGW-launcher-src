using UnityEngine;

public class MainWindowDragDispatcher : MonoBehaviour
{
}

using engine.unity;

public class NativeMainWindowController : MonoSingleton<NativeMainWindowController>
{
}

using UnityEngine;

public class PanWithMouse : MonoBehaviour
{
	public Vector2 degrees;
	public float range;
}

namespace Microsoft.IO
{
	public class RecyclableMemoryStreamManager
	{
	}
}

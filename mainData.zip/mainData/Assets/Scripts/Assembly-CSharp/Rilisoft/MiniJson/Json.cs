namespace Rilisoft.MiniJson
{
	public class Json
	{
	}
}

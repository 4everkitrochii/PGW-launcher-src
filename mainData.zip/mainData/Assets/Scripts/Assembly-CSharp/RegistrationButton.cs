using UnityEngine;

public class RegistrationButton : MonoBehaviour
{
	public UIWidget clickBoxDisable;
}

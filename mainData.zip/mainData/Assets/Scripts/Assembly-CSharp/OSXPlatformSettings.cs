using engine.launcher;

public class OSXPlatformSettings : IPlatformSettings
{
}

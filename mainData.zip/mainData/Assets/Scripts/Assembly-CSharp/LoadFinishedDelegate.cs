public delegate void LoadFinishedDelegate(UWKWebView view);

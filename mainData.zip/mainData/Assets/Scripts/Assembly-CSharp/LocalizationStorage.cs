public class LocalizationStorage
{
}

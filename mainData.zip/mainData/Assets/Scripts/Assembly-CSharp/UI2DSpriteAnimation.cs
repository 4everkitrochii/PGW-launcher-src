using UnityEngine;

public class UI2DSpriteAnimation : MonoBehaviour
{
	public int framerate;
	public bool ignoreTimeScale;
	public Sprite[] frames;
}

using UnityEngine;

public class UICursor : MonoBehaviour
{
	public Camera uiCamera;
}

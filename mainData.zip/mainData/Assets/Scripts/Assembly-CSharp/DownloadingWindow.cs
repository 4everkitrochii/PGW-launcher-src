using UnityEngine;

public class DownloadingWindow : MonoBehaviour
{
	public ProgressBar Progress;
	public ButtonLabel DownloadButton;
	public UIButton GameButton;
	public UILabel Message;
	public UILabel Nick;
	public UIButton Logout;
	public ButtonLabel MailValidityButton;
}

using UnityEngine;

public class AnimatedAlpha : MonoBehaviour
{
	public float alpha;
}

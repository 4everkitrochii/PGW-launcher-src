using engine.integrations;

public class IntegrationsManager : IIntegrationCallback
{
	private IntegrationsManager()
	{
	}

}

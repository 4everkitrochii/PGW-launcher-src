using System.Collections.Generic;

public delegate void JSMessageReceivedDelegate(UWKWebView view,string message,string json,Dictionary<string, object> values);

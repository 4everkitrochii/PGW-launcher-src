using UnityEngine;
using System.Collections.Generic;

public class InvDatabase : MonoBehaviour
{
	public int databaseID;
	public List<InvBaseItem> items;
	public UIAtlas iconAtlas;
}

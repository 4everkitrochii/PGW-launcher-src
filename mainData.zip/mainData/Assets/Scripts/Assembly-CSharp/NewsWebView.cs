using UnityEngine;

public class NewsWebView : MonoBehaviour
{
	public UITexture WebViewTexture;
}

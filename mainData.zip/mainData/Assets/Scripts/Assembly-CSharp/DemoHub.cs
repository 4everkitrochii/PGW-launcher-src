using BestHTTP.SignalR.Hubs;

internal class DemoHub : Hub
{
	public DemoHub() : base(default(string))
	{
	}

}

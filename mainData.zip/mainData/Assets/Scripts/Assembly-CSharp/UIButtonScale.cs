using UnityEngine;

public class UIButtonScale : MonoBehaviour
{
	public Transform tweenTarget;
	public Vector3 hover;
	public Vector3 pressed;
	public float duration;
}

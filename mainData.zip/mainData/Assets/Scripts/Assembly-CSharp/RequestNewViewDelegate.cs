public delegate void RequestNewViewDelegate(UWKWebView view,string url);

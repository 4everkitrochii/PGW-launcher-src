using UnityEngine;

public class PlayIdleAnimations : MonoBehaviour
{
}

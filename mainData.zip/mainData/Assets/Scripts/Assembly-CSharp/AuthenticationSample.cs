using UnityEngine;

internal class AuthenticationSample : MonoBehaviour
{
}

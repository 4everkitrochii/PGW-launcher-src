using UnityEngine;

public class LoadLevelOnClick : MonoBehaviour
{
	public string levelName;
}

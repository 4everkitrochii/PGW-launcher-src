using UnityEngine;

public class TweenTransform : UITweener
{
	public Transform from;
	public Transform to;
	public bool parentWhenFinished;
}

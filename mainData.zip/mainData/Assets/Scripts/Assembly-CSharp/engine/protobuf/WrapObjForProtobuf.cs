namespace engine.protobuf
{
	public class WrapObjForProtobuf
	{
	}
}

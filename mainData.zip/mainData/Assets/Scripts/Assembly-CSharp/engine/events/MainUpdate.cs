namespace engine.events
{
	public class MainUpdate : DependSceneEvent<MainUpdate>
	{
	}
}

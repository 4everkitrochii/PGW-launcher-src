namespace engine.events
{
	public class ApplicationFocusUnityEvent : DependSceneEvent<ApplicationFocusUnityEvent, bool>
	{
	}
}

namespace engine.events
{
	public class DependSceneEvent<EventType, ArgumentType> : BaseEvent<ArgumentType>
	{
	}
}

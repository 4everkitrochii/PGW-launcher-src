namespace engine.events
{
	public class AbstractEvent
	{
	}
}

namespace engine.events
{
	public class ISubscriptionEvent
	{
	}
}

namespace engine.events
{
	public class BaseEvent : AbstractEvent
	{
	}
}

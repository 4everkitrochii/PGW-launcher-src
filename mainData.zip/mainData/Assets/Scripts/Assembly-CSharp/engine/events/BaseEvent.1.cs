namespace engine.events
{
	public class BaseEvent<ArgumentEvent> : AbstractEvent
	{
	}
}

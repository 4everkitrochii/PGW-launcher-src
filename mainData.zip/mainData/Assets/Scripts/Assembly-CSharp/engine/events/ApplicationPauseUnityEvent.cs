namespace engine.events
{
	public class ApplicationPauseUnityEvent : DependSceneEvent<ApplicationPauseUnityEvent, bool>
	{
	}
}

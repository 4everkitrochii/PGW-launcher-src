namespace engine.events
{
	public class ApplicationQuitUnityEvent : DependSceneEvent<ApplicationQuitUnityEvent>
	{
	}
}

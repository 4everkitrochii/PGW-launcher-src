namespace engine.events
{
	public class EventManager
	{
		private EventManager()
		{
		}

	}
}

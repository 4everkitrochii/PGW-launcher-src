namespace engine.events
{
	public class DependSceneEvent<EventType> : BaseEvent
	{
	}
}

using System;

namespace engine.events
{
	public class SubscriptionUID
	{
		public SubscriptionUID(Action<SubscriptionUID> unsubscribeAction)
		{
		}

	}
}

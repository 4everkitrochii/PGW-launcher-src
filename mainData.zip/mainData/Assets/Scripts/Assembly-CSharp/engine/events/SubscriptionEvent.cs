using System;

namespace engine.events
{
	public class SubscriptionEvent
	{
		public SubscriptionEvent(Action action, Func<bool> filter)
		{
		}

	}
}

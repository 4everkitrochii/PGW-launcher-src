namespace engine.events
{
	public class MainUpdateOneSecond : DependSceneEvent<MainUpdateOneSecond>
	{
	}
}

namespace engine.events
{
	public class ChangeSceneUnityEvent : DependSceneEvent<ChangeSceneUnityEvent>
	{
	}
}

namespace engine.events
{
	public class DependSceneSubscriptions
	{
	}
}

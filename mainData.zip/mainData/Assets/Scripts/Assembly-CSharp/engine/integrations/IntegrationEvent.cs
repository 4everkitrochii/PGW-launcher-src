namespace engine.integrations
{
	public class IntegrationEvent
	{
		public IntegrationEvent(IntegrationEventType type)
		{
		}

	}
}

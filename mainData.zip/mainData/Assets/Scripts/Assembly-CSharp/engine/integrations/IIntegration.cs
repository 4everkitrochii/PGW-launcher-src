namespace engine.integrations
{
	public class IIntegration
	{
	}
}

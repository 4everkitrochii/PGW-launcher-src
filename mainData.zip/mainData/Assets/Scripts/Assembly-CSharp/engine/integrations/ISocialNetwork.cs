namespace engine.integrations
{
	public class ISocialNetwork : IIntegration
	{
	}
}

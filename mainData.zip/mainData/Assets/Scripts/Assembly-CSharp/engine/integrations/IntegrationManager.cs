namespace engine.integrations
{
	public class IntegrationManager
	{
		private IntegrationManager()
		{
		}

	}
}

namespace engine.integrations
{
	public class IIntegrationCallback
	{
	}
}

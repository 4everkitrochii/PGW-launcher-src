namespace engine.network
{
	public class TestServerEvent1 : AbstractServerCommand
	{
	}
}

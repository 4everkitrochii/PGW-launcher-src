using engine.events;

namespace engine.network
{
	public class ConnectionStatusEvent : BaseEvent<ConnectionStatusEventArg>
	{
	}
}

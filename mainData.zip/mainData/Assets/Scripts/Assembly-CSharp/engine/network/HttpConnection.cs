namespace engine.network
{
	public class HttpConnection : BaseConnection
	{
		public HttpConnection(string serverUrl) : base(default(string), default(string))
		{
		}

	}
}

namespace engine.network
{
	public class WebSocketConnection : BaseConnection
	{
		public WebSocketConnection(string serverUrl, string authKey) : base(default(string), default(string))
		{
		}

	}
}

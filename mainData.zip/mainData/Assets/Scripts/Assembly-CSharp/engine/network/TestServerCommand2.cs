namespace engine.network
{
	public class TestServerCommand2 : AbstractServerCommand
	{
		public int C;
		public int D;
	}
}

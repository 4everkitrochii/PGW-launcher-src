namespace engine.network
{
	public class AbstractServerCommand
	{
	}
}

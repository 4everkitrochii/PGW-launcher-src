namespace engine.network
{
	public class ServerCommandCodeResult
	{
	}
}

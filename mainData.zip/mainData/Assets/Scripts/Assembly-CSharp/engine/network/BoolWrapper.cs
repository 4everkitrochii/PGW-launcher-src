namespace engine.network
{
	public class BoolWrapper
	{
		public BoolWrapper(bool isTrue)
		{
		}

	}
}

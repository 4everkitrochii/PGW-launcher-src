namespace engine.network
{
	public class ServerCommandInfo
	{
		public int code;
		public string message;
		public int sequence;
	}
}

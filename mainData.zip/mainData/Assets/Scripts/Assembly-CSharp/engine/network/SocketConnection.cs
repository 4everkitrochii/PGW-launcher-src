namespace engine.network
{
	public class SocketConnection : BaseConnection
	{
		public SocketConnection(string serverUrl) : base(default(string), default(string))
		{
		}

	}
}

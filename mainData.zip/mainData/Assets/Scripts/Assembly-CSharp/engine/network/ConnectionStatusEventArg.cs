namespace engine.network
{
	public class ConnectionStatusEventArg
	{
		public string message;
	}
}

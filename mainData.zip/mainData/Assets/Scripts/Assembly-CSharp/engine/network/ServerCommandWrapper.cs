namespace engine.network
{
	public class ServerCommandWrapper
	{
		public int typeId;
		public byte[] typeData;
	}
}

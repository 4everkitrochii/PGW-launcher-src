namespace engine.network
{
	public class ServerInfo
	{
		public ServerInfo(string ServerURL, string AuthPath, string RegistrationPath, string EnterPath, string AppKey)
		{
		}

	}
}

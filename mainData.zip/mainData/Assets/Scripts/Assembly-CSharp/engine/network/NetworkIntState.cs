using engine.events;

namespace engine.network
{
	public class NetworkIntState : BaseEvent<BoolWrapper>
	{
	}
}

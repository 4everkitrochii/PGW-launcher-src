using engine.events;

namespace engine.network.auth
{
	public class AuthManager : BaseEvent<AuthEventParams>
	{
	}
}

namespace engine.network
{
	public class TestServerCommand1 : AbstractServerCommand
	{
		public int A;
		public int B;
	}
}

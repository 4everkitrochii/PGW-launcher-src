namespace engine.network
{
	public class RequestStatus
	{
	}
}

namespace engine.network
{
	public class SimpleServerResponseCommand : AbstractServerCommand
	{
	}
}

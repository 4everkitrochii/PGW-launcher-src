namespace engine.controllers
{
	public class CheatsChecker
	{
		private CheatsChecker()
		{
		}

	}
}

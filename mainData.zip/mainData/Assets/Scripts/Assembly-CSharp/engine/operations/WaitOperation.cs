namespace engine.operations
{
	public class WaitOperation : Operation
	{
		public WaitOperation(float duration)
		{
		}

	}
}

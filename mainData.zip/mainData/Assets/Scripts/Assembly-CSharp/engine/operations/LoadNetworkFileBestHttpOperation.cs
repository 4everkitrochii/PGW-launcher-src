using engine.filesystem;

namespace engine.operations
{
	public class LoadNetworkFileBestHttpOperation : LoadFileOperation
	{
		public LoadNetworkFileBestHttpOperation(string url, BaseAssetFile file)
		{
		}

	}
}

namespace engine.operations
{
	public class OperationsManager
	{
		private OperationsManager()
		{
		}

	}
}

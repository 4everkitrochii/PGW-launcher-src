using engine.filesystem;

namespace engine.operations
{
	public class LoadFileInTreadOperation : LoadFileOperation
	{
		public LoadFileInTreadOperation(BaseAssetFile file)
		{
		}

	}
}

using engine.filesystem;

namespace engine.operations
{
	public class LoadNetworkFileOperation : LoadFileOperation
	{
		public LoadNetworkFileOperation(string url, BaseAssetFile file)
		{
		}

	}
}

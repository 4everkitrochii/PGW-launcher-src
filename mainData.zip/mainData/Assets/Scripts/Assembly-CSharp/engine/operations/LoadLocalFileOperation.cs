using engine.filesystem;

namespace engine.operations
{
	public class LoadLocalFileOperation : LoadFileOperation
	{
		public LoadLocalFileOperation(string folderName, BaseAssetFile assetFile)
		{
		}

	}
}

using engine.network;

namespace engine.operations
{
	public class ConnectOperation : Operation
	{
		public ConnectOperation(string serverUrl, string authKey, BaseConnection.ConnectionType connectionType, float reconnectInterval)
		{
		}

	}
}

namespace engine.operations
{
	public class TheradOperation : Operation
	{
	}
}

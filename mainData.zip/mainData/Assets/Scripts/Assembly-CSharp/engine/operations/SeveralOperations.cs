namespace engine.operations
{
	public class SeveralOperations : Operation
	{
		public SeveralOperations(Operation[] operations)
		{
		}

	}
}

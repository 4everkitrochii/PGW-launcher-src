namespace engine.operations
{
	public class OperationQueueSelfThread : OperationQueue
	{
	}
}

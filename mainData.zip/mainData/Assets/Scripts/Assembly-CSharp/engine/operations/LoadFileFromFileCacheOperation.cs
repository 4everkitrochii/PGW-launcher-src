using engine.filesystem;

namespace engine.operations
{
	public class LoadFileFromFileCacheOperation : LoadFileOperation
	{
		public LoadFileFromFileCacheOperation(BaseAssetFile file, bool resources)
		{
		}

	}
}

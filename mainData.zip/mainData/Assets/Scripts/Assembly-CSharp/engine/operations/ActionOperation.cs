using System;

namespace engine.operations
{
	public class ActionOperation : Operation
	{
		public ActionOperation(Action method)
		{
		}

	}
}

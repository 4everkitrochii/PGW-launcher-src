using engine.events;

namespace engine.operations
{
	public class ProgressEvent : BaseEvent<float>
	{
	}
}

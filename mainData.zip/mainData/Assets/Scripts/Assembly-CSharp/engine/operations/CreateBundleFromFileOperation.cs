using engine.filesystem;

namespace engine.operations
{
	public class CreateBundleFromFileOperation : Operation
	{
		public CreateBundleFromFileOperation(AssetBundleFile file)
		{
		}

	}
}

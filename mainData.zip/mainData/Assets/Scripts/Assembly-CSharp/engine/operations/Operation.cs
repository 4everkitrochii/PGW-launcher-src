using engine.events;

namespace engine.operations
{
	public class Operation : BaseEvent<Operation>
	{
	}
}

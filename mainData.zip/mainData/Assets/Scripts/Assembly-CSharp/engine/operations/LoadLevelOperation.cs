namespace engine.operations
{
	public class LoadLevelOperation : Operation
	{
		public LoadLevelOperation(int levelIndex, bool isAdditive)
		{
		}

	}
}

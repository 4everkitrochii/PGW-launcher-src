using engine.events;

namespace engine.data
{
	public class BaseSharedSettings : BaseEvent
	{
	}
}

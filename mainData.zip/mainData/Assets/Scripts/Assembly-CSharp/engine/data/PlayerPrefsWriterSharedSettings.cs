namespace engine.data
{
	public class PlayerPrefsWriterSharedSettings : IReadWriterShredSettings
	{
		public PlayerPrefsWriterSharedSettings(BaseSharedSettings settings) : base(default(BaseSharedSettings))
		{
		}

	}
}

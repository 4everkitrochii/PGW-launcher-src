namespace engine.data
{
	public class JSONReadWriterSharedSettings : IReadWriterShredSettings
	{
		public JSONReadWriterSharedSettings(BaseSharedSettings settings) : base(default(BaseSharedSettings))
		{
		}

	}
}

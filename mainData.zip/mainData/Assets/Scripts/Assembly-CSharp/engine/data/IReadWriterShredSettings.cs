namespace engine.data
{
	public class IReadWriterShredSettings
	{
		protected IReadWriterShredSettings(BaseSharedSettings settings)
		{
		}

	}
}

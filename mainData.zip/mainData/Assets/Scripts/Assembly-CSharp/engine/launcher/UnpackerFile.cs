using engine.events;

namespace engine.launcher
{
	public class UnpackerFile : BaseEvent<UnpackerFileEventArgs>
	{
	}
}

namespace engine.launcher
{
	public class VersionInfo
	{
	}
}

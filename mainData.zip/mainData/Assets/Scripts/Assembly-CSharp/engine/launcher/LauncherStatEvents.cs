namespace engine.launcher
{
	public enum LauncherStatEvents
	{
		START_DOWNLOADING_LAUNCHER = 1,
		END_DOWNLOADING_LAUNCHER = 2,
		UNPACKED_LAUNCHER = 3,
		START_DOWNLOADING_GAME = 4,
		END_DOWNLOADING_GAME = 5,
		UNPACKED_GAME = 6,
	}
}

namespace engine.launcher
{
	public class LauncherStatNetwork
	{
		private LauncherStatNetwork()
		{
		}

	}
}

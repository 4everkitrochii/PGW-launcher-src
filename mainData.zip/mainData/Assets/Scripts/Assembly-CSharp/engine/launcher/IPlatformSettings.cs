namespace engine.launcher
{
	public class IPlatformSettings
	{
	}
}

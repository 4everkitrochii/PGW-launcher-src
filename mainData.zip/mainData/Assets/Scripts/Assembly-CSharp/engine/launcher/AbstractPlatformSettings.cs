namespace engine.launcher
{
	public class AbstractPlatformSettings
	{
	}
}

using engine.events;

namespace engine.launcher
{
	public class LauncherStatDispatcher : BaseEvent<LauncherStatArgs>
	{
		private LauncherStatDispatcher()
		{
		}

	}
}

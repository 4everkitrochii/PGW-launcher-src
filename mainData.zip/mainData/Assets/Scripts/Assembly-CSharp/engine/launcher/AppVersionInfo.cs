namespace engine.launcher
{
	public class AppVersionInfo
	{
		public string title;
		public string urlTorrent;
		public string url;
		public string urlTorrentCDN;
		public string urlCDN;
		public string fileName;
		public string rootDirectory;
	}
}

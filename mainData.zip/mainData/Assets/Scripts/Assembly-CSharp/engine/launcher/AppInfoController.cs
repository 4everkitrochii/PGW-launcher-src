using engine.events;

namespace engine.launcher
{
	public class AppInfoController : BaseEvent
	{
		private AppInfoController()
		{
		}

	}
}

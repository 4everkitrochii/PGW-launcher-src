namespace engine.launcher
{
	public class AppGameVersionInfo
	{
		public bool isUseTorrent;
	}
}

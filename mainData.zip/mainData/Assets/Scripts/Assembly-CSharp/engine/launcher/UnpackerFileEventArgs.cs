namespace engine.launcher
{
	public class UnpackerFileEventArgs
	{
		public float progress;
		public long maxValue;
		public string error;
	}
}

namespace engine.launcher
{
	public class AverageSpeedNetwork
	{
	}
}

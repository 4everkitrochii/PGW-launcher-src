namespace engine.launcher
{
	public class UpdateControllerEventArgs
	{
		public double progress;
		public long receivedBytes;
		public long totalBytes;
		public int speed;
	}
}

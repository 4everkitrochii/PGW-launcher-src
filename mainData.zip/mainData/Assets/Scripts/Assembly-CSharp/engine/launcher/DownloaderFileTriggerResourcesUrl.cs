namespace engine.launcher
{
	public class DownloaderFileTriggerResourcesUrl
	{
	}
}

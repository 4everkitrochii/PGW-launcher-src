using engine.events;

namespace engine.launcher
{
	public class DownloadFilesController : BaseEvent<DownloaderFileEventArgs>
	{
	}
}

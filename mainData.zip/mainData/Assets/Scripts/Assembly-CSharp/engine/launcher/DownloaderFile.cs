using engine.events;

namespace engine.launcher
{
	public class DownloaderFile : BaseEvent<DownloaderFileEventArgs>
	{
		private DownloaderFile()
		{
		}

	}
}

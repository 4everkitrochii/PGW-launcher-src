namespace engine.helpers
{
	public class XoredFloat : XoredValue<float>
	{
	}
}

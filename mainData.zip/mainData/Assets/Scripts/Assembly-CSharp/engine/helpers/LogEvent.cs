using engine.events;

namespace engine.helpers
{
	public class LogEvent : DependSceneEvent<LogEvent, LogEventArgs>
	{
	}
}

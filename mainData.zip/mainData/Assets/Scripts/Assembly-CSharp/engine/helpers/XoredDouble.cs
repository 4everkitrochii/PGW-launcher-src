namespace engine.helpers
{
	public class XoredDouble : XoredValue<double>
	{
	}
}

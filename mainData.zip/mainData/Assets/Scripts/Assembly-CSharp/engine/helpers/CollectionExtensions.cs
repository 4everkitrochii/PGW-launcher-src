namespace engine.helpers
{
	public class CollectionExtensions
	{
	}
}

namespace engine.helpers
{
	public class MovingAverage
	{
		public MovingAverage(uint maxSamples)
		{
		}

	}
}

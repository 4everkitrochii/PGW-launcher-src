namespace engine.helpers
{
	public class XoredInt : XoredValue<int>
	{
	}
}

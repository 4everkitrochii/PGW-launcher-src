namespace engine.helpers
{
	public class XoredLong : XoredValue<long>
	{
	}
}

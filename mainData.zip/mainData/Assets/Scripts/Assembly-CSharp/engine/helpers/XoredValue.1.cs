namespace engine.helpers
{
	public class XoredValue<T>
	{
	}
}

namespace engine.helpers
{
	public class Utility
	{
	}
}

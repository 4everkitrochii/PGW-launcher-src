namespace engine.helpers
{
	public class Flags
	{
	}
}

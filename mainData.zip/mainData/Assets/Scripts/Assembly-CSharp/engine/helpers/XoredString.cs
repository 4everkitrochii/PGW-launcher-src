namespace engine.helpers
{
	public class XoredString : XoredValue<string>
	{
	}
}

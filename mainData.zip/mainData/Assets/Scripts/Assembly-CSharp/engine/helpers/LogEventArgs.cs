using UnityEngine;

namespace engine.helpers
{
	public class LogEventArgs
	{
		public string condition;
		public string stackTrace;
		public LogType type;
	}
}

using UnityEngine;

namespace engine.unity
{
	public class UITabContent : MonoBehaviour
	{
		public UIWidget container;
	}
}

using UnityEngine;

namespace engine.unity
{
	public class MonoSingleton<T> : MonoBehaviour
	{
	}
}

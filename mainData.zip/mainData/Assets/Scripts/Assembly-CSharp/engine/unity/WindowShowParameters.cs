namespace engine.unity
{
	public class WindowShowParameters
	{
	}
}

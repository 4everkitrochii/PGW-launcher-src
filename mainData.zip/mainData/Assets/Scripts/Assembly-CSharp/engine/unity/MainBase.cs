using UnityEngine;

namespace engine.unity
{
	public class MainBase : MonoBehaviour
	{
	}
}

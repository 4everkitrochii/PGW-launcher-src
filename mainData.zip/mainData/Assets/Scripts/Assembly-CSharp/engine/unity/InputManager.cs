namespace engine.unity
{
	public class InputManager
	{
	}
}

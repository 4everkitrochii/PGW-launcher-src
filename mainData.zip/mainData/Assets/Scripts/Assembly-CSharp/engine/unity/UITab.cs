using UnityEngine;

namespace engine.unity
{
	public class UITab : MonoBehaviour
	{
		public UITabState defaultState;
		public UITabState selectedState;
		public bool locked;
	}
}

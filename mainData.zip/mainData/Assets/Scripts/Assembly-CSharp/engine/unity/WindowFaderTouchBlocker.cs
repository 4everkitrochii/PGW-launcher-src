using UnityEngine;

namespace engine.unity
{
	public class WindowFaderTouchBlocker : MonoBehaviour
	{
	}
}

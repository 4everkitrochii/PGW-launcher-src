using engine.events;

namespace engine.unity
{
	public class WindowController : BaseEvent
	{
		private WindowController()
		{
		}

	}
}

namespace engine.unity
{
	public class AbstractScreen
	{
	}
}

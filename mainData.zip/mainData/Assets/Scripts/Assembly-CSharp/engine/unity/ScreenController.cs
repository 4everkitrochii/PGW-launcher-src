namespace engine.unity
{
	public class ScreenController
	{
		private ScreenController()
		{
		}

	}
}

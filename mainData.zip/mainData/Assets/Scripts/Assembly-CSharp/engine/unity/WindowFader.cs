using UnityEngine;

namespace engine.unity
{
	public class WindowFader : MonoBehaviour
	{
		public UISprite Fader;
		public UIPlayTween Tweener;
	}
}

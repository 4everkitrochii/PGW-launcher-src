namespace engine.filesystem
{
	public class FileCache
	{
		private FileCache()
		{
		}

	}
}

using System;

namespace engine.filesystem
{
	public struct FileName
	{
		public FileName(string name, uint ts, string url) : this()
		{
		}

	}
}

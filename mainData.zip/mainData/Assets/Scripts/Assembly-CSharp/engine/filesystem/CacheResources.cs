namespace engine.filesystem
{
	public class CacheResources
	{
		public CacheResources(byte[] bytes, bool resorces)
		{
		}

	}
}

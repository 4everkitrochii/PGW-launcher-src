namespace engine.filesystem
{
	public class AssetBundleFile : BaseAssetFile
	{
	}
}

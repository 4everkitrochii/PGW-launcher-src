namespace engine.filesystem
{
	public class BaseAssetFile
	{
	}
}

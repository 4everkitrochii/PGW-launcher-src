namespace engine.filesystem
{
	public class TextureAssetFile : BaseAssetFile
	{
	}
}

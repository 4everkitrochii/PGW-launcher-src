namespace engine.filesystem
{
	public class ResourcesManager
	{
		private ResourcesManager()
		{
		}

	}
}

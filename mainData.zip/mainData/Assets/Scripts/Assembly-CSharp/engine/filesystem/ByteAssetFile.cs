namespace engine.filesystem
{
	public class ByteAssetFile : BaseAssetFile
	{
	}
}

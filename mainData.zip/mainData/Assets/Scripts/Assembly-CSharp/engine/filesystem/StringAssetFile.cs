namespace engine.filesystem
{
	public class StringAssetFile : BaseAssetFile
	{
	}
}

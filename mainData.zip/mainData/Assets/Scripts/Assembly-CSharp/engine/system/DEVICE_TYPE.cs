namespace engine.system
{
	public enum DEVICE_TYPE
	{
		STANDALONE = 0,
		PHONE = 1,
		TABLET = 2,
	}
}

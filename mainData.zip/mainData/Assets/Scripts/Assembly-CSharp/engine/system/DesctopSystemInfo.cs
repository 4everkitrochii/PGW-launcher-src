namespace engine.system
{
	public class DesctopSystemInfo : ISystemInfo
	{
	}
}

namespace engine.system
{
	public class TYPE_ATLAS
	{
	}
}

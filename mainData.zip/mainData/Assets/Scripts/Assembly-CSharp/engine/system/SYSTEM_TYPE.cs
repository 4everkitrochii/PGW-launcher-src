namespace engine.system
{
	public class SYSTEM_TYPE
	{
	}
}

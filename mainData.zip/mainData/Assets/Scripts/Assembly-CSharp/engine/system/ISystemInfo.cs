namespace engine.system
{
	public class ISystemInfo
	{
	}
}

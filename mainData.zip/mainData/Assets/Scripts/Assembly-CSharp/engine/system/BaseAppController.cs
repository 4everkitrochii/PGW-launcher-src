using engine.events;

namespace engine.system
{
	public class BaseAppController : BaseEvent
	{
	}
}

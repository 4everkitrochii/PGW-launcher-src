public class OsxWindowHandler : BaseWindowHandler
{
}

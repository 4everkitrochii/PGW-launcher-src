using UnityEngine;

public class LagPosition : MonoBehaviour
{
	public int updateOrder;
	public Vector3 speed;
	public bool ignoreTimeScale;
}

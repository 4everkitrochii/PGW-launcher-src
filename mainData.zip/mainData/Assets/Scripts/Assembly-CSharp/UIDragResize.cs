using UnityEngine;

public class UIDragResize : MonoBehaviour
{
	public UIWidget target;
	public UIWidget.Pivot pivot;
	public int minWidth;
	public int minHeight;
	public int maxWidth;
	public int maxHeight;
}

using engine.network;

public class LauncherServerInfo : ServerInfo
{
	public LauncherServerInfo(string serverCDNUrl, string ServerURL, string AuthPath, string RegistrationPath, string EnterPath, string AppKey) : base(default(string), default(string), default(string), default(string), default(string))
	{
	}

}

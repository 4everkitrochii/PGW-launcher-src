using UnityEngine;

public class DownloadTexture : MonoBehaviour
{
	public string url;
}

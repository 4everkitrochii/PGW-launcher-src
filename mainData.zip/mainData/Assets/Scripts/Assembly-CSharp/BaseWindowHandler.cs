public class BaseWindowHandler
{
}

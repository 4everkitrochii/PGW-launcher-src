using UnityEngine;

public class GameWindow : MonoBehaviour
{
	public NewsWebView newsWindow;
	public DownloadingWindow downloadingWindow;
}

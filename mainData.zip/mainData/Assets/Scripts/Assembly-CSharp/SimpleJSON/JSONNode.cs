namespace SimpleJSON
{
	public class JSONNode
	{
	}
}

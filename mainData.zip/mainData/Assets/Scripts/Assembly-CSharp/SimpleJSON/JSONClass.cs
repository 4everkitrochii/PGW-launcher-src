namespace SimpleJSON
{
	public class JSONClass : JSONNode
	{
	}
}

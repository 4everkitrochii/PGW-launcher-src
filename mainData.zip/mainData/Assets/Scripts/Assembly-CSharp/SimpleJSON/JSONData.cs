namespace SimpleJSON
{
	public class JSONData : JSONNode
	{
		public JSONData(string aData)
		{
		}

	}
}

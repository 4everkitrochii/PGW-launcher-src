namespace SimpleJSON
{
	public class JSONArray : JSONNode
	{
	}
}

namespace SimpleJSON
{
	public class JSON
	{
	}
}

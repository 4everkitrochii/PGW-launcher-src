namespace SimpleJSON
{
	internal class JSONLazyCreator : JSONNode
	{
		public JSONLazyCreator(JSONNode aNode)
		{
		}

	}
}

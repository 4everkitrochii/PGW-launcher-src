public delegate void AsyncMessageDelegate(uint id,string value);

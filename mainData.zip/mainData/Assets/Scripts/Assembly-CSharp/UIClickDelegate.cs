using UnityEngine;

public class UIClickDelegate : MonoBehaviour
{
	public UIWidget clickHandler;
}

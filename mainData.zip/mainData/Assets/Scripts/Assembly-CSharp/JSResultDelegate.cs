public delegate void JSResultDelegate(UWKWebView view,uint id,string result);

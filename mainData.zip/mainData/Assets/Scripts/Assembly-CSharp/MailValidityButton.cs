using UnityEngine;

public class MailValidityButton : MonoBehaviour
{
}

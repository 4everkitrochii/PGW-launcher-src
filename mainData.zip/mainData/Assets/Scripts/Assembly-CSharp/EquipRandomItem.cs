using UnityEngine;

public class EquipRandomItem : MonoBehaviour
{
	public InvEquipment equipment;
}

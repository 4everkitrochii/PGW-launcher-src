using UnityEngine;

public class MessageClick : MonoBehaviour
{
}

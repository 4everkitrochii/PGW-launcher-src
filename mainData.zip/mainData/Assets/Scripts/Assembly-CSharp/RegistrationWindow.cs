using UnityEngine;

public class RegistrationWindow : MonoBehaviour
{
	public UIInput Email;
	public UIInput Password;
	public RegistrationButton Registration;
	public UIButton AutoRegister;
	public UILabel Response;
	public UIToggle IsRules;
	public UILabel EmailErrorLabel;
	public UILabel PassErrorLabel;
	public UILabel RegisterErrorlabel;
}

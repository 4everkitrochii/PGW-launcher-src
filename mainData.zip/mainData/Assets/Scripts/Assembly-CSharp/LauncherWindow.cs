using UnityEngine;

public class LauncherWindow : MonoBehaviour
{
	public UILabel description;
	public GameWindow gameWindow;
	public StartWindow startWindow;
}

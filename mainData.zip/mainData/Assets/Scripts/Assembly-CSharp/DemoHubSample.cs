using UnityEngine;

internal class DemoHubSample : MonoBehaviour
{
}

using UnityEngine;

public class EnvelopContent : MonoBehaviour
{
	public Transform targetRoot;
	public int padLeft;
	public int padRight;
	public int padBottom;
	public int padTop;
}

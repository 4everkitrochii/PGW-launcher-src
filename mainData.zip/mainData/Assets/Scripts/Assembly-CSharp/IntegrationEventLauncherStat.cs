using engine.integrations;

public class IntegrationEventLauncherStat : IntegrationEvent
{
	public IntegrationEventLauncherStat() : base(default(IntegrationEventType))
	{
	}

}

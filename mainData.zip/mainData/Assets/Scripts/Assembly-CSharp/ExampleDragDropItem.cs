using UnityEngine;

public class ExampleDragDropItem : UIDragDropItem
{
	public GameObject prefab;
}

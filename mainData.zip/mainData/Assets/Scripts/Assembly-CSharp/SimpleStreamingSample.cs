using UnityEngine;

internal class SimpleStreamingSample : MonoBehaviour
{
}

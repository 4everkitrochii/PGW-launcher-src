public delegate void JSConsoleDelegate(UWKWebView view,string message,int line,string source);

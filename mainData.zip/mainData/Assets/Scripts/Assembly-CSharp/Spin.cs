using UnityEngine;

public class Spin : MonoBehaviour
{
	public Vector3 rotationsPerSecond;
	public bool ignoreTimeScale;
}

using UnityEngine;

internal class ConnectionStatusSample : MonoBehaviour
{
}

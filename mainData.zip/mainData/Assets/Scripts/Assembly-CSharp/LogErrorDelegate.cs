public delegate void LogErrorDelegate(string message,bool fatal);

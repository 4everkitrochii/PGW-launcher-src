namespace BestHTTP
{
	public class HTTPProxy
	{
	}
}

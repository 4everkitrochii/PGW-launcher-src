namespace BestHTTP
{
	public class IProtocol
	{
	}
}

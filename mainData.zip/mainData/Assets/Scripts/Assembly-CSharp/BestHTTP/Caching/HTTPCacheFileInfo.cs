using System;

namespace BestHTTP.Caching
{
	internal class HTTPCacheFileInfo
	{
		internal HTTPCacheFileInfo(Uri uri)
		{
		}

	}
}

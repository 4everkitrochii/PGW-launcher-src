using System;

namespace BestHTTP.Caching
{
	public class HTTPCacheMaintananceParams
	{
		public HTTPCacheMaintananceParams(TimeSpan deleteOlder, ulong maxCacheSize)
		{
		}

	}
}

namespace BestHTTP.Caching
{
	internal class HTTPCacheFileLock
	{
	}
}

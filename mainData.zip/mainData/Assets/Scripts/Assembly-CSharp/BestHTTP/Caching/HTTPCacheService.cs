namespace BestHTTP.Caching
{
	public class HTTPCacheService
	{
	}
}

namespace BestHTTP.Extensions
{
	public class Extensions
	{
	}
}

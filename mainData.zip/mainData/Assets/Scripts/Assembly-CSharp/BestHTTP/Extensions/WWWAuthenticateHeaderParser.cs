namespace BestHTTP.Extensions
{
	public class WWWAuthenticateHeaderParser : KeyValuePairList
	{
		public WWWAuthenticateHeaderParser(string headerValue)
		{
		}

	}
}

namespace BestHTTP.Extensions
{
	public class HeartbeatManager
	{
	}
}

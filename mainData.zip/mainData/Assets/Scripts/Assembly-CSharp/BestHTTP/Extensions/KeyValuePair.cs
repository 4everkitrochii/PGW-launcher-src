namespace BestHTTP.Extensions
{
	public class KeyValuePair
	{
		public KeyValuePair(string key)
		{
		}

	}
}

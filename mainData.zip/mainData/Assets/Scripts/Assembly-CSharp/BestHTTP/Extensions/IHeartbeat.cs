namespace BestHTTP.Extensions
{
	public class IHeartbeat
	{
	}
}

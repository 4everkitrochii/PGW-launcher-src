namespace BestHTTP
{
	internal class HTTPProtocolFactory
	{
	}
}

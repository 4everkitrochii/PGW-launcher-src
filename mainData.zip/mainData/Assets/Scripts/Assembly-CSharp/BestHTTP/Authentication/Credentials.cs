namespace BestHTTP.Authentication
{
	public class Credentials
	{
		public Credentials(string userName, string password)
		{
		}

	}
}

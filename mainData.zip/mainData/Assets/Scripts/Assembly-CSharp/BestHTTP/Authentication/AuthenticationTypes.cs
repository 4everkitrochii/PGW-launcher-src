namespace BestHTTP.Authentication
{
	public enum AuthenticationTypes
	{
		Unknown = 0,
		Basic = 1,
		Digest = 2,
	}
}

using System;

namespace BestHTTP.Authentication
{
	internal class Digest
	{
		internal Digest(Uri uri)
		{
		}

	}
}

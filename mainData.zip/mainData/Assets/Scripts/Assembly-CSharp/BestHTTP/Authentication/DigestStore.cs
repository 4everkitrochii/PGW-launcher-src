namespace BestHTTP.Authentication
{
	internal class DigestStore
	{
	}
}

namespace BestHTTP.Forms
{
	public class HTTPFormBase
	{
	}
}

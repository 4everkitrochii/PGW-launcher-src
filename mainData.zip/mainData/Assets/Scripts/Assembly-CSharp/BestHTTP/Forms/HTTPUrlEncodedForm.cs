namespace BestHTTP.Forms
{
	public class HTTPUrlEncodedForm : HTTPFormBase
	{
	}
}

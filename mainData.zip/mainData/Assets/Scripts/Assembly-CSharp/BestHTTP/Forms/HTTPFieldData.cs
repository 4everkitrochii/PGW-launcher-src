namespace BestHTTP.Forms
{
	public class HTTPFieldData
	{
	}
}

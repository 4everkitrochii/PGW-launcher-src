namespace BestHTTP.Forms
{
	public enum HTTPFormUsage
	{
		Automatic = 0,
		UrlEncoded = 1,
		Multipart = 2,
		Unity = 3,
	}
}

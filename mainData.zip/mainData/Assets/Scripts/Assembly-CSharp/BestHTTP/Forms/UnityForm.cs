namespace BestHTTP.Forms
{
	public class UnityForm : HTTPFormBase
	{
	}
}

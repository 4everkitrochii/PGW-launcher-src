namespace BestHTTP.Forms
{
	public class HTTPMultiPartForm : HTTPFormBase
	{
	}
}

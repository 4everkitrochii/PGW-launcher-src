namespace BestHTTP
{
	public enum SupportedProtocols
	{
		Unknown = 0,
		HTTP = 1,
		WebSocket = 2,
		ServerSentEvents = 3,
	}
}

namespace BestHTTP
{
	internal class HTTPConnection
	{
		internal HTTPConnection(string serverAddress)
		{
		}

	}
}

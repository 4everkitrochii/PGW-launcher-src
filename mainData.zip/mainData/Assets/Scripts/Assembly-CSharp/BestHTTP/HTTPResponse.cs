using System.IO;

namespace BestHTTP
{
	public class HTTPResponse
	{
		internal HTTPResponse(HTTPRequest request, Stream stream, bool isStreamed, bool isFromCache)
		{
		}

	}
}

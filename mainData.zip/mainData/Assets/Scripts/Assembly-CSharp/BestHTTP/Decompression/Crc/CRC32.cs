namespace BestHTTP.Decompression.Crc
{
	internal class CRC32
	{
	}
}

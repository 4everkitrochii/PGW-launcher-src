namespace BestHTTP.Decompression.Zlib
{
	internal enum DeflateFlavor
	{
		Store = 0,
		Fast = 1,
		Slow = 2,
	}
}

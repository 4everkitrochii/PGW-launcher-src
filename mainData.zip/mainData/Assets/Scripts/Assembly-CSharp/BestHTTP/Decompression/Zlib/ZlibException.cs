using System;

namespace BestHTTP.Decompression.Zlib
{
	internal class ZlibException : Exception
	{
	}
}

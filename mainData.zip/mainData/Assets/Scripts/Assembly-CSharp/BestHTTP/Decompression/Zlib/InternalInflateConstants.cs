namespace BestHTTP.Decompression.Zlib
{
	internal class InternalInflateConstants
	{
	}
}

namespace BestHTTP.Decompression.Zlib
{
	public class ZlibConstants
	{
	}
}

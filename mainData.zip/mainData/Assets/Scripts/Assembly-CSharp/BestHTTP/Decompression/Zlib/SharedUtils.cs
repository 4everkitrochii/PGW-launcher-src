namespace BestHTTP.Decompression.Zlib
{
	internal class SharedUtils
	{
	}
}

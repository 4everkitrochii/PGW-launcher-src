namespace BestHTTP.Decompression.Zlib
{
	internal class DeflateManager
	{
	}
}

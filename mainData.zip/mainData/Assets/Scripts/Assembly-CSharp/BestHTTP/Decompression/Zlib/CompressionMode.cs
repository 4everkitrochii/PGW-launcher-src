namespace BestHTTP.Decompression.Zlib
{
	public enum CompressionMode
	{
		Compress = 0,
		Decompress = 1,
	}
}

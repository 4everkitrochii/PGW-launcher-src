namespace BestHTTP.Decompression.Zlib
{
	internal class InternalConstants
	{
	}
}

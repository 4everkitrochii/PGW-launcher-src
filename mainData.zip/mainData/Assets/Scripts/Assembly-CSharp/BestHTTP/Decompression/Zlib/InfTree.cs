namespace BestHTTP.Decompression.Zlib
{
	internal class InfTree
	{
	}
}

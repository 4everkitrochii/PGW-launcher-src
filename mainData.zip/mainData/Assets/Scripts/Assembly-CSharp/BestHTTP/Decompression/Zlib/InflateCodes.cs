namespace BestHTTP.Decompression.Zlib
{
	internal class InflateCodes
	{
	}
}

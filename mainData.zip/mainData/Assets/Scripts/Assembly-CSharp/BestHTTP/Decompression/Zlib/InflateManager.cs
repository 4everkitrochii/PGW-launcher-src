namespace BestHTTP.Decompression.Zlib
{
	internal class InflateManager
	{
	}
}

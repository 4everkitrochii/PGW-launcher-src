namespace BestHTTP.Decompression.Zlib
{
	public enum CompressionStrategy
	{
		Default = 0,
		Filtered = 1,
		HuffmanOnly = 2,
	}
}

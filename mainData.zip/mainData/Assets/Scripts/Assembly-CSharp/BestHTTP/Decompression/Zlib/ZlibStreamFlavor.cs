namespace BestHTTP.Decompression.Zlib
{
	internal enum ZlibStreamFlavor
	{
		ZLIB = 1950,
		DEFLATE = 1951,
		GZIP = 1952,
	}
}

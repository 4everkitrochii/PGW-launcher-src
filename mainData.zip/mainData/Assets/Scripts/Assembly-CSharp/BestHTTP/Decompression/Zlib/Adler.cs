namespace BestHTTP.Decompression.Zlib
{
	public class Adler
	{
	}
}

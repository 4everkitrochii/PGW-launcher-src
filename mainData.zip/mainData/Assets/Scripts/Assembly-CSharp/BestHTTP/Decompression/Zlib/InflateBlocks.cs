namespace BestHTTP.Decompression.Zlib
{
	internal class InflateBlocks
	{
		internal InflateBlocks(ZlibCodec codec, object checkfn, int w)
		{
		}

	}
}

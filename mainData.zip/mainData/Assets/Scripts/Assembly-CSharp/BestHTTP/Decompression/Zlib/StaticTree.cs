namespace BestHTTP.Decompression.Zlib
{
	internal class StaticTree
	{
		private StaticTree(short[] treeCodes, int[] extraBits, int extraBase, int elems, int maxLength)
		{
		}

	}
}

namespace BestHTTP.SignalR.JsonEncoders
{
	public class DefaultJsonEncoder
	{
	}
}

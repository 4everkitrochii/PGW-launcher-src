namespace BestHTTP.SignalR.JsonEncoders
{
	public class IJsonEncoder
	{
	}
}

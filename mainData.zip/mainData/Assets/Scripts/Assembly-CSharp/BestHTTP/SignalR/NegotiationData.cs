namespace BestHTTP.SignalR
{
	public class NegotiationData
	{
		public NegotiationData(Connection connection)
		{
		}

	}
}

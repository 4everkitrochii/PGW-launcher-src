namespace BestHTTP.SignalR
{
	public enum TransportTypes
	{
		WebSocket = 0,
		ServerSentEvents = 1,
		LongPoll = 2,
	}
}

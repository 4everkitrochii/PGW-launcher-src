namespace BestHTTP.SignalR.Messages
{
	public class IServerMessage
	{
	}
}

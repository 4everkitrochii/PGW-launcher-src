namespace BestHTTP.SignalR.Messages
{
	public class MethodCallMessage
	{
	}
}

namespace BestHTTP.SignalR.Messages
{
	public class MultiMessage
	{
	}
}

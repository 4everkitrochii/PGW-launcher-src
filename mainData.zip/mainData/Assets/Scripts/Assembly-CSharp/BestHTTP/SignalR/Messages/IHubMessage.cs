namespace BestHTTP.SignalR.Messages
{
	public class IHubMessage
	{
	}
}

namespace BestHTTP.SignalR.Messages
{
	public class KeepAliveMessage
	{
	}
}

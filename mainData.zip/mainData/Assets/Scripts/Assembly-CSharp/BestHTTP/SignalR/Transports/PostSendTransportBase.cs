using BestHTTP.SignalR;

namespace BestHTTP.SignalR.Transports
{
	public class PostSendTransportBase : TransportBase
	{
		public PostSendTransportBase(string name, Connection con) : base(default(string), default(Connection))
		{
		}

	}
}

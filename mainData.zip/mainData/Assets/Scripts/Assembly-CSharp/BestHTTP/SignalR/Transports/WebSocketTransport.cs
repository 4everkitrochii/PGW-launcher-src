using BestHTTP.SignalR;

namespace BestHTTP.SignalR.Transports
{
	public class WebSocketTransport : TransportBase
	{
		public WebSocketTransport(Connection connection) : base(default(string), default(Connection))
		{
		}

	}
}

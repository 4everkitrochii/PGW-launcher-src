namespace BestHTTP.SignalR
{
	public class IConnection
	{
	}
}

namespace BestHTTP.SignalR.Hubs
{
	public class IHub
	{
	}
}

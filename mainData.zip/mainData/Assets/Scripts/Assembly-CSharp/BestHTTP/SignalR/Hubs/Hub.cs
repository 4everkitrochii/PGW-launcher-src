namespace BestHTTP.SignalR.Hubs
{
	public class Hub
	{
		public Hub(string name)
		{
		}

	}
}

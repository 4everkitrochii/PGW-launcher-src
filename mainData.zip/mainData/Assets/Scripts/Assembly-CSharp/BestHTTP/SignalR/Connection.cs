using System;

namespace BestHTTP.SignalR
{
	public class Connection
	{
		public Connection(Uri uri)
		{
		}

	}
}

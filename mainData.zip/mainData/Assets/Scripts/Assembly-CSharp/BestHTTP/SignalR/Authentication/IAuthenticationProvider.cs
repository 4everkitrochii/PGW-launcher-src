namespace BestHTTP.SignalR.Authentication
{
	public class IAuthenticationProvider
	{
	}
}

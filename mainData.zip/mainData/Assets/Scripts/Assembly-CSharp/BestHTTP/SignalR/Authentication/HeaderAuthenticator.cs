namespace BestHTTP.SignalR.Authentication
{
	internal class HeaderAuthenticator
	{
		public HeaderAuthenticator(string user, string roles)
		{
		}

	}
}

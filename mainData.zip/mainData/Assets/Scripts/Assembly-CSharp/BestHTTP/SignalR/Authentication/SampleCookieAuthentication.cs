using System;

namespace BestHTTP.SignalR.Authentication
{
	public class SampleCookieAuthentication
	{
		public SampleCookieAuthentication(Uri authUri, string user, string passwd, string roles)
		{
		}

	}
}

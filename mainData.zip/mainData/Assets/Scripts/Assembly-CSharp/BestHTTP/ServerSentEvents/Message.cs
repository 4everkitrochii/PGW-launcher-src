namespace BestHTTP.ServerSentEvents
{
	public class Message
	{
	}
}

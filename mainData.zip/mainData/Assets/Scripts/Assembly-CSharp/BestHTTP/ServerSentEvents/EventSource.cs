using System;

namespace BestHTTP.ServerSentEvents
{
	public class EventSource
	{
		public EventSource(Uri uri)
		{
		}

	}
}

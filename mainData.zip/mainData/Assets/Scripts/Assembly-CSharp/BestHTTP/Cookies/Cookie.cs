namespace BestHTTP.Cookies
{
	public class Cookie
	{
		public Cookie(string name, string value)
		{
		}

	}
}

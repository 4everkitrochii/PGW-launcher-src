namespace BestHTTP.Cookies
{
	public class CookieJar
	{
	}
}

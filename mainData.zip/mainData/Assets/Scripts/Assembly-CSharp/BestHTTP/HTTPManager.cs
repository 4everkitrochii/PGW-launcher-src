namespace BestHTTP
{
	public class HTTPManager
	{
	}
}

namespace BestHTTP.JSON
{
	public class Json
	{
	}
}

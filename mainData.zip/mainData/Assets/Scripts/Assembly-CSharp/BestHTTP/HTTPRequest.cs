using System;

namespace BestHTTP
{
	public class HTTPRequest
	{
		public HTTPRequest(Uri uri)
		{
		}

	}
}

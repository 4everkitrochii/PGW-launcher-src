using System;

namespace BestHTTP.WebSocket
{
	public class WebSocket
	{
		public WebSocket(Uri uri)
		{
		}

	}
}

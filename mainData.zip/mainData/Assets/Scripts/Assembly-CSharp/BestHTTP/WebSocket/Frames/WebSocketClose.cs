namespace BestHTTP.WebSocket.Frames
{
	public class WebSocketClose : WebSocketBinaryFrame
	{
		public WebSocketClose() : base(default(byte[]))
		{
		}

	}
}

namespace BestHTTP.WebSocket.Frames
{
	public class WebSocketBinaryFrame
	{
		public WebSocketBinaryFrame(byte[] data)
		{
		}

	}
}

namespace BestHTTP.WebSocket.Frames
{
	public class WebSocketFrameReader
	{
	}
}

namespace BestHTTP
{
	public class HTTPRange
	{
	}
}

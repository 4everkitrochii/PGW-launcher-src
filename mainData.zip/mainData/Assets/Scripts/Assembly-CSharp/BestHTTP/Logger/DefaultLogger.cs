namespace BestHTTP.Logger
{
	public class DefaultLogger
	{
	}
}

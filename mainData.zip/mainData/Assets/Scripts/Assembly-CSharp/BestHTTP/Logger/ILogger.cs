namespace BestHTTP.Logger
{
	public class ILogger
	{
	}
}

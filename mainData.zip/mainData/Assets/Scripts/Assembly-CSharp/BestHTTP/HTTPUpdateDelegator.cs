using UnityEngine;

namespace BestHTTP
{
	internal class HTTPUpdateDelegator : MonoBehaviour
	{
	}
}

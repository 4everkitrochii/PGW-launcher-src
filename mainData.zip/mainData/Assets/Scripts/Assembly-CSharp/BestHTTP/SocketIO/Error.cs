namespace BestHTTP.SocketIO
{
	public class Error
	{
		public Error(SocketIOErrors code, string msg)
		{
		}

	}
}

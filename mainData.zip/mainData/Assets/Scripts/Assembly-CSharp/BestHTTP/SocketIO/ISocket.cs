namespace BestHTTP.SocketIO
{
	internal class ISocket
	{
	}
}

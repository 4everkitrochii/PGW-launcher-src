namespace BestHTTP.SocketIO.JsonEncoders
{
	public class LitJsonEncoder
	{
	}
}

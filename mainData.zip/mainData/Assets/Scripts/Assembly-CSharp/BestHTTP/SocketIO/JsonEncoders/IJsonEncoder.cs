namespace BestHTTP.SocketIO.JsonEncoders
{
	public class IJsonEncoder
	{
	}
}

namespace BestHTTP.SocketIO
{
	public class Socket
	{
		internal Socket(string nsp, SocketManager manager)
		{
		}

	}
}

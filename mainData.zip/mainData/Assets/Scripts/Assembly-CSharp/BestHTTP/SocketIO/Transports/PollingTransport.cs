using BestHTTP.SocketIO;

namespace BestHTTP.SocketIO.Transports
{
	internal class PollingTransport
	{
		public PollingTransport(SocketManager manager)
		{
		}

	}
}

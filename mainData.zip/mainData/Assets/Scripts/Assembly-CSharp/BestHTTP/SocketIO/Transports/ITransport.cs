namespace BestHTTP.SocketIO.Transports
{
	public class ITransport
	{
	}
}

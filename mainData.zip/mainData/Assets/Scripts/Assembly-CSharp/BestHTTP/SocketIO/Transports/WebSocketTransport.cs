using BestHTTP.SocketIO;

namespace BestHTTP.SocketIO.Transports
{
	internal class WebSocketTransport
	{
		public WebSocketTransport(SocketManager manager)
		{
		}

	}
}

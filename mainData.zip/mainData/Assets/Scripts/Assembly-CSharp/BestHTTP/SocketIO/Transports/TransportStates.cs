namespace BestHTTP.SocketIO.Transports
{
	public enum TransportStates
	{
		Connecting = 0,
		Opening = 1,
		Open = 2,
		Closed = 3,
		Paused = 4,
	}
}

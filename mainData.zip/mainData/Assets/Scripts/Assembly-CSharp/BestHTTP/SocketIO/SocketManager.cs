using System;

namespace BestHTTP.SocketIO
{
	public class SocketManager
	{
		public SocketManager(Uri uri)
		{
		}

	}
}

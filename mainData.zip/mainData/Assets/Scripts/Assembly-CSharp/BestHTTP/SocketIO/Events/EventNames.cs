namespace BestHTTP.SocketIO.Events
{
	public class EventNames
	{
	}
}

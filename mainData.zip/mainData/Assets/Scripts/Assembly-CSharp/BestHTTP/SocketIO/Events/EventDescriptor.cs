namespace BestHTTP.SocketIO.Events
{
	internal class EventDescriptor
	{
		public EventDescriptor(bool onlyOnce, bool autoDecodePayload, SocketIOCallback callback)
		{
		}

	}
}

using BestHTTP.SocketIO;

namespace BestHTTP.SocketIO.Events
{
	internal class EventTable
	{
		public EventTable(Socket socket)
		{
		}

	}
}

namespace BestHTTP.SocketIO
{
	public class Packet
	{
	}
}

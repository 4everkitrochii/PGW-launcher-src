namespace BestHTTP.SocketIO
{
	public class HandshakeData
	{
		public HandshakeData(SocketManager manager)
		{
		}

	}
}

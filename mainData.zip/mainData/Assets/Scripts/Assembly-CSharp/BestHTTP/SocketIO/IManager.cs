namespace BestHTTP.SocketIO
{
	internal class IManager
	{
	}
}

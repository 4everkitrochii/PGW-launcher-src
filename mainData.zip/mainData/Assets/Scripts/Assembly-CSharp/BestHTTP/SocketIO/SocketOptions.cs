namespace BestHTTP.SocketIO
{
	public class SocketOptions
	{
	}
}

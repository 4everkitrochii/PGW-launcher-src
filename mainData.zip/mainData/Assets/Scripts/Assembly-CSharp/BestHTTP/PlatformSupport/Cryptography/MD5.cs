using System.Security.Cryptography;

namespace BestHTTP.PlatformSupport.Cryptography
{
	public class MD5 : HashAlgorithm
	{
	}
}

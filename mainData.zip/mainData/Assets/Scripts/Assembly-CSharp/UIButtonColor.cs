using UnityEngine;

public class UIButtonColor : UIWidgetContainer
{
	public GameObject tweenTarget;
	public Color hover;
	public Color pressed;
	public Color disabledColor;
	public float duration;
}

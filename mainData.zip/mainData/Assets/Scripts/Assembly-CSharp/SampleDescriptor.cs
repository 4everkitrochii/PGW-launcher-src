using System;

public class SampleDescriptor
{
	public SampleDescriptor(Type type, string displayName, string description, string codeBlock)
	{
	}

}

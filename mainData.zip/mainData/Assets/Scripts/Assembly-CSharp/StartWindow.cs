using UnityEngine;

public class StartWindow : MonoBehaviour
{
	public AuthWindows authWindow;
	public RegistrationWindow registrationWindow;
}

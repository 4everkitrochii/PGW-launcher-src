using UnityEngine;

public class SpringPanel : MonoBehaviour
{
	public Vector3 target;
	public float strength;
}

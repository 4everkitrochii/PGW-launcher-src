public class ByteReader
{
	public ByteReader(byte[] bytes)
	{
	}

}

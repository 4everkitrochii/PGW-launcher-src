using UnityEngine;

public class AssetBundleSample : MonoBehaviour
{
}

public class LauncherStatHelper
{
	private LauncherStatHelper()
	{
	}

}

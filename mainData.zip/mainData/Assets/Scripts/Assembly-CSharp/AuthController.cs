using engine.events;

public class AuthController : BaseEvent<AuthControllerEventArgs>
{
}

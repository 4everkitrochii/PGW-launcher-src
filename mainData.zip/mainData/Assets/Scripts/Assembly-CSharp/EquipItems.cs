using UnityEngine;

public class EquipItems : MonoBehaviour
{
	public int[] itemIDs;
}

using UnityEngine;

public class TweenColor : UITweener
{
	public Color from;
	public Color to;
}

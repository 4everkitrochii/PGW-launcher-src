using System.Collections.Generic;

namespace Tasharen
{
	public class DataNode
	{
		public string name;
		public List<DataNode> children;
	}
}

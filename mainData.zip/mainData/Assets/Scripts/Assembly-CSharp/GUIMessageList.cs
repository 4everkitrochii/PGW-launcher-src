public class GUIMessageList
{
}

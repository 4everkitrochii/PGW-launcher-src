using UnityEngine;

public class UICenterOnClick : MonoBehaviour
{
}

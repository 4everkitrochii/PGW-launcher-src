public class NGUIText
{
	public enum Alignment
	{
		Automatic = 0,
		Left = 1,
		Center = 2,
		Right = 3,
		Justified = 4,
	}

	public enum SymbolStyle
	{
		None = 0,
		Normal = 1,
		Colored = 2,
	}

}

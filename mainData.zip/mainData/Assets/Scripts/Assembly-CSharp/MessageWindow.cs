using engine.unity;
using UnityEngine;

public class MessageWindow : BaseWindow
{
	public UILabel messageLabel;
	public UIButton closeButton;
	public UIButton okButton;
	public UILabel okLabel;
	public UILabel messageLabel_BAN;
	public UIButton okButton_BAN;
	public UILabel okLabel_BAN;
	public GameObject BanWindow;
	public GameObject NormalWindow;
}

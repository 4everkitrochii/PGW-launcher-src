using BestHTTP.SignalR.Hubs;

internal class TypedDemoHub : Hub
{
	public TypedDemoHub() : base(default(string))
	{
	}

}

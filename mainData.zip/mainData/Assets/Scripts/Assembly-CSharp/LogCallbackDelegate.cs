public delegate void LogCallbackDelegate(string message,int level);

using UnityEngine;

public class LagRotation : MonoBehaviour
{
	public int updateOrder;
	public float speed;
	public bool ignoreTimeScale;
}

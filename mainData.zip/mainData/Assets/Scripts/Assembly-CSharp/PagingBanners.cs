using UnityEngine;

public class PagingBanners : MonoBehaviour
{
	public GameObject pagingBackgroundPrefab;
	public UISprite selector;
}

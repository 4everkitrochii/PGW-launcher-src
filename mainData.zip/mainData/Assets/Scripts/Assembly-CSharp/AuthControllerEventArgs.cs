public class AuthControllerEventArgs
{
	public int requestStatus;
	public string message;
}

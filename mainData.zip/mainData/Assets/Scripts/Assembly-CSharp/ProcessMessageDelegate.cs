using System;

public delegate void ProcessMessageDelegate(IntPtr pcmd);

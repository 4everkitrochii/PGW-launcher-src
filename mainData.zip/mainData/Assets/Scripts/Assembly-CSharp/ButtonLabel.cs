using UnityEngine;

public class ButtonLabel : MonoBehaviour
{
	public UIButton Button;
	public UILabel Label;
}

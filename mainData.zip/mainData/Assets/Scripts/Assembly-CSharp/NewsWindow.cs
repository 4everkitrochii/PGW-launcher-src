using engine.unity;

public class NewsWindow : UITabContent
{
}

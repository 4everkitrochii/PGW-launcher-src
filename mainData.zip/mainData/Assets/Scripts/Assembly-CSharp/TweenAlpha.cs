public class TweenAlpha : UITweener
{
	public float from;
	public float to;
}

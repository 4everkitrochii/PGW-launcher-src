using UnityEngine;

public class BannerScroller : MonoBehaviour
{
	public GameObject scrollView;
	public GameObject gridScrollView;
	public GameObject bannerPrefab;
	public PagingBanners paggingBanners;
	public UISprite leftArrow;
	public UISprite rightArrow;
}

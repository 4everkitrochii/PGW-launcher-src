public class NGUIMath
{
}

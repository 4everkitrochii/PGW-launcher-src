using UnityEngine;

public class OpenURLOnClick : MonoBehaviour
{
}

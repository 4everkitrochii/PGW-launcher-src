using UnityEngine;

public class AnimatedColor : MonoBehaviour
{
	public Color color;
}

using UnityEngine;

public class ShaderQuality : MonoBehaviour
{
}

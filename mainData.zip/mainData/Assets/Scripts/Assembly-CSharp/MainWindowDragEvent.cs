using engine.events;

public class MainWindowDragEvent : BaseEvent
{
}

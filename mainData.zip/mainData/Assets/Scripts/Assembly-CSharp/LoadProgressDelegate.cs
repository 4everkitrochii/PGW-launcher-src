public delegate void LoadProgressDelegate(UWKWebView view,int progress);

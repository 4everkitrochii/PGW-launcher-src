using UnityEngine;

public class InvEquipment : MonoBehaviour
{
}

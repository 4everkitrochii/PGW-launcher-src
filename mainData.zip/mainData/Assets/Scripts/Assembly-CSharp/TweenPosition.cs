using UnityEngine;

public class TweenPosition : UITweener
{
	public Vector3 from;
	public Vector3 to;
	public bool worldSpace;
}

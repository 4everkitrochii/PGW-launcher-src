using UnityEngine;

public class BannerIcon : MonoBehaviour
{
}

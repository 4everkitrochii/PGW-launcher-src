public class JSObject
{
}

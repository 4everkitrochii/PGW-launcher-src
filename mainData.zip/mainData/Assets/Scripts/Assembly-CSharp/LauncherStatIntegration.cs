using engine.integrations;

public class LauncherStatIntegration : IIntegration
{
}

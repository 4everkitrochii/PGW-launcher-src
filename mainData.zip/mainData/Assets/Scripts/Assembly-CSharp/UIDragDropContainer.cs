using UnityEngine;

public class UIDragDropContainer : MonoBehaviour
{
	public Transform reparentTarget;
}

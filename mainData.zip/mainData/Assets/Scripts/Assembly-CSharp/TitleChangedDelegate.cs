public delegate void TitleChangedDelegate(UWKWebView view,string title);

public class NGUITools
{
}

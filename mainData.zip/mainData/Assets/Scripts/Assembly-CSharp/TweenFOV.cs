public class TweenFOV : UITweener
{
	public float from;
	public float to;
}

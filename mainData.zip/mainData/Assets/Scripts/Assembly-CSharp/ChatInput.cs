using UnityEngine;

public class ChatInput : MonoBehaviour
{
	public UITextList textList;
	public bool fillWithDummyData;
}

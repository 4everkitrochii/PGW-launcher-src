public class TweenOrthoSize : UITweener
{
	public float from;
	public float to;
}

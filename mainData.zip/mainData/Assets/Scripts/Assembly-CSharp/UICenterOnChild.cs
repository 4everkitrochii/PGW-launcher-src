using UnityEngine;

public class UICenterOnChild : MonoBehaviour
{
	public float springStrength;
	public float nextPageThreshold;
}

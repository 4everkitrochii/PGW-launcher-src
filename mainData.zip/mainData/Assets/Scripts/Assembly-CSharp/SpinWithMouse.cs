using UnityEngine;

public class SpinWithMouse : MonoBehaviour
{
	public Transform target;
	public float speed;
}

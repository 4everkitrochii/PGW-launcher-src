using UnityEngine;

namespace I2.Loc
{
	public class tk2dChangeLanguage : MonoBehaviour
	{
	}
}

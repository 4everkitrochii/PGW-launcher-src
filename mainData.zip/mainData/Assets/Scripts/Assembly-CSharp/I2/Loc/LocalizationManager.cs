namespace I2.Loc
{
	public class LocalizationManager
	{
	}
}

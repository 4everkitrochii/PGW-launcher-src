namespace I2.Loc
{
	public enum eSpreadsheetUpdateMode
	{
		None = 0,
		Replace = 1,
		Merge = 2,
		AddNewTerms = 3,
	}
}

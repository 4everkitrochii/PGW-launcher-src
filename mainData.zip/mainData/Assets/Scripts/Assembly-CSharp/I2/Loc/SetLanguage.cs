using UnityEngine;

namespace I2.Loc
{
	public class SetLanguage : MonoBehaviour
	{
		public string _Language;
	}
}

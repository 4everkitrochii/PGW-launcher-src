namespace I2.Loc
{
	public class LocalizationReader
	{
	}
}

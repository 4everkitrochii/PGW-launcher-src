using UnityEngine;

namespace I2.Loc
{
	public class ToggleLanguage : MonoBehaviour
	{
	}
}

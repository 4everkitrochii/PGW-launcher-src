using UnityEngine;

namespace I2.Loc
{
	public class ResourceManager : MonoBehaviour
	{
		public Object[] Assets;
	}
}

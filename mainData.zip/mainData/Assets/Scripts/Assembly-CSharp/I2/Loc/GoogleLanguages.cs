namespace I2.Loc
{
	public class GoogleLanguages
	{
	}
}

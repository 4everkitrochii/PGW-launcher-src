using UnityEngine;

namespace I2.Loc
{
	public class LanguagePopup : MonoBehaviour
	{
		public LanguageSource Source;
	}
}

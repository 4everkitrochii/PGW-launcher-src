using UnityEngine;

namespace I2.Loc
{
	public class CallbackNotification : MonoBehaviour
	{
	}
}

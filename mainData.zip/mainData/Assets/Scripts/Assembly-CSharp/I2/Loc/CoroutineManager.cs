using UnityEngine;

namespace I2.Loc
{
	public class CoroutineManager : MonoBehaviour
	{
	}
}

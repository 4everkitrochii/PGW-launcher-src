namespace I2.Loc
{
	public enum eTermType
	{
		Text = 0,
		Font = 1,
		Texture = 2,
		AudioClip = 3,
		GameObject = 4,
		Sprite = 5,
		UIAtlas = 6,
		UIFont = 7,
		Object = 8,
	}
}

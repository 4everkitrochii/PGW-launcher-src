public class MessageWindowLogout : MessageWindow
{
	public UIButton cancelButton;
	public UILabel cancelLabel;
}

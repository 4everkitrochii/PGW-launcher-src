namespace AnimationOrTween
{
	public enum EnableCondition
	{
		DoNothing = 0,
		EnableThenPlay = 1,
	}
}

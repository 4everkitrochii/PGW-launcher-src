namespace AnimationOrTween
{
	public enum Direction
	{
		Reverse = -1,
		Toggle = 0,
		Forward = 1,
	}
}

public delegate void JSEvalDelegate(string value);

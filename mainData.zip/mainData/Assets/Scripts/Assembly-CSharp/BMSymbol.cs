using System;

[Serializable]
public class BMSymbol
{
	public string sequence;
	public string spriteName;
}

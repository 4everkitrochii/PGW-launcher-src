using UnityEngine;

public class NGUIDebug : MonoBehaviour
{
}

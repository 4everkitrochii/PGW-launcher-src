namespace LegacySystem
{
	public class Thread
	{
		public Thread(ThreadStart start)
		{
		}

	}
}

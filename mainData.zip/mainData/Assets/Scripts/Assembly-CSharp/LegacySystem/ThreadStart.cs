namespace LegacySystem
{
	public delegate void ThreadStart();
}

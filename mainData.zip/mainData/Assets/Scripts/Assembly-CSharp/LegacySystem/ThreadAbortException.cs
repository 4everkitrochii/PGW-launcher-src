using System;

namespace LegacySystem
{
	public class ThreadAbortException : Exception
	{
	}
}

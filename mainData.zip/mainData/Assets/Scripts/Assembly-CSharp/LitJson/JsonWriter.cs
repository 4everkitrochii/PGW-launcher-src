namespace LitJson
{
	public class JsonWriter
	{
	}
}

namespace LitJson
{
	public class JsonMockWrapper
	{
	}
}

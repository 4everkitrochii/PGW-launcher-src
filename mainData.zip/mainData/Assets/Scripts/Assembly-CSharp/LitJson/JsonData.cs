namespace LitJson
{
	public class JsonData
	{
	}
}

namespace LitJson
{
	public class JsonReader
	{
		public JsonReader(string json_text)
		{
		}

	}
}

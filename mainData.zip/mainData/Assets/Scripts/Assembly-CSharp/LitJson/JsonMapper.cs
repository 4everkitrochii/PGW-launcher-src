namespace LitJson
{
	public class JsonMapper
	{
	}
}

using System;

namespace LitJson
{
	internal struct PropertyMetadata
	{
		public bool IsField;
	}
}

namespace LitJson
{
	public class IOrderedDictionary
	{
	}
}

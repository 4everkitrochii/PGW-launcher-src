using System;

namespace LitJson
{
	internal struct ArrayMetadata
	{
	}
}

using System;

namespace LitJson
{
	public class JsonException : Exception
	{
	}
}

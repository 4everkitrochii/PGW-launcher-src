namespace LitJson
{
	public enum JsonType
	{
		None = 0,
		Object = 1,
		Array = 2,
		String = 3,
		Int = 4,
		Long = 5,
		Double = 6,
		Boolean = 7,
	}
}

using System;

namespace LitJson
{
	internal struct ObjectMetadata
	{
	}
}

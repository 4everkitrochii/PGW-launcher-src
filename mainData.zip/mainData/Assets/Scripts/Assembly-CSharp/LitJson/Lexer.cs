using System.IO;

namespace LitJson
{
	internal class Lexer
	{
		public Lexer(TextReader reader)
		{
		}

	}
}

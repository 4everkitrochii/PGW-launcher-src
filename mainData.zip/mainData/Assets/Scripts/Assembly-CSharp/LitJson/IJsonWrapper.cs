namespace LitJson
{
	public class IJsonWrapper
	{
	}
}

using System.Collections.Generic;

namespace LitJson
{
	internal class OrderedDictionaryEnumerator
	{
		public OrderedDictionaryEnumerator(IEnumerator<KeyValuePair<string, JsonData>> enumerator)
		{
		}

	}
}

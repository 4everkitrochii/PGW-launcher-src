namespace LitJson
{
	internal class FsmContext
	{
		public bool Return;
		public int NextState;
		public int StateStack;
	}
}

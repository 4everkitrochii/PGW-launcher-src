using UnityEngine;

public class UIButtonActivate : MonoBehaviour
{
	public GameObject target;
	public bool state;
}

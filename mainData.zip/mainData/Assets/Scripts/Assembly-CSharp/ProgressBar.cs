using UnityEngine;

public class ProgressBar : MonoBehaviour
{
	public int numberOfSteps;
	public UILabel messageLabel;
}
